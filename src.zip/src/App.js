// ✅ App.js (hoàn chỉnh)
import { useState } from 'react';
import SidebarMenu from './components/SidebarMenu';
import WordTable from './components/WordTable';
import Dashboard from './components/Dashboard';
import AddWordForm from './components/AddWordForm';
import FillInTheBlankGame from './components/FillInTheBlankGame';
import MatchingGame from './components/MatchingGame';
import FlashCardView from './components/FlashCardView';
import WriteWordGame from './components/WriteWordGame';
import QuizGame from './components/QuizGame';
import LearningFlow from './components/LearningFlow';
import './index.css';
import { FaBars } from 'react-icons/fa';
import { useWordStore } from './hooks/useWordStore';

// Kiểm tra các import để đảm bảo rằng các component được xuất đúng cách từ file của chúng.
// Nếu một component không được xuất đúng cách, hãy sửa file của component đó để thêm `export default`.

const PAGE_TITLES = {
  dashboard: 'Tổng quan',
  vocab: 'Bảng từ vựng',
  spaced: 'Lặp lại ngắt quãng',
  topics: 'Theo chủ đề',
  'game-fill': 'Điền từ thiếu',
  'game-match': 'Nối từ',
  'game-write': 'Viết lại',
  'game-quiz': 'Trắc nghiệm',
  'flash-card': 'Flash Card',
  notes: 'Ghi chú & Ôn tập',
  levels: 'Theo cấp độ',
  roadmap: 'Theo lộ trình',
  stats: 'Thống kê',
  reminder: 'Nhắc nhở',
  sync: 'Đồng bộ dữ liệu',
  account: 'Tài khoản',
  export: 'Xuất từ vựng',
  import: 'Nhập từ vựng',
  learningflow: 'Học liền mạch'
};

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [menuOpen, setMenuOpen] = useState(false);

  const {
    words,
    addWord,
    toggleFavorite,
    deleteWord,
    updateIPA,
    fetchIPAAndAudioOnly,
    wordExists,
    getWordsForToday
  } = useWordStore();

  const handleLearningFinish = (results) => {
    console.log('Kết quả buổi học:', results);
    alert('Buổi học đã hoàn thành!');
  };

  // Lấy danh sách từ cần ôn hôm nay
  const reviewWords = getWordsForToday ? getWordsForToday() : [];

  return (
    <div className="flex h-screen overflow-hidden font-inter bg-gradient-to-br from-pastel-green via-pastel-blue to-pastel-pink">
      {/* Sidebar */}
      <button
        className="md:hidden fixed top-4 left-4 z-50 p-3 bg-white shadow-md rounded-xl hover:bg-pastel-blue transition"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Mở menu"
      >
        <FaBars />
      </button>
      <div
        className={`z-40 bg-white shadow-xl rounded-r-2xl border-r border-pastel-green h-full transition-all duration-300
          ${menuOpen ? 'w-64' : 'w-0'}
          overflow-hidden md:w-64 md:flex`}
      >
        <SidebarMenu onSelect={key => { setCurrentPage(key); setMenuOpen(false); }} currentPage={currentPage} />
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-2 md:p-6 transition-all duration-300">
        <div className="max-w-5xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-extrabold text-center text-pastel-navy drop-shadow-sm tracking-tight">
              {PAGE_TITLES[currentPage] || 'Vocab App'}
            </h1>
          </div>
          <div className="transition-all duration-300">
            {currentPage === 'dashboard' && (
              <div className="animate-fade-in">
                <Dashboard words={words} getWordsForToday={getWordsForToday} />
              </div>
            )}
            {currentPage === 'learning-flow' && (
              reviewWords.length > 0 ? (
                <LearningFlow words={reviewWords} onFinish={handleLearningFinish} />
              ) : (
                <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                  <div className="text-2xl font-bold mb-2">🎉 Không có từ nào cần ôn hôm nay!</div>
                  <div>Bạn đã hoàn thành ôn tập. Hãy thêm từ mới hoặc quay lại sau.</div>
                </div>
              )
            )}
            {currentPage === 'vocab' && (
              <div className="space-y-6 animate-fade-in">
                <AddWordForm
                  onAdd={addWord}
                  fetchIPAAndAudioOnly={fetchIPAAndAudioOnly}
                  wordExists={wordExists}
                />
                <WordTable
                  words={words}
                  onToggleFavorite={toggleFavorite}
                  onDelete={deleteWord}
                  onUpdateIPA={updateIPA}
                />
              </div>
            )}

            {currentPage === 'spaced' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Lặp lại ngắt quãng</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'topics' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Học theo chủ đề</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'game-fill' && (
              <div className="animate-fade-in">
                <FillInTheBlankGame words={words} />
              </div>
            )}
            {currentPage === 'game-match' && (
              <div className="animate-fade-in">
                <MatchingGame words={words} />
              </div>
            )}
            {currentPage === 'game-write' && (
              <div className="animate-fade-in">
                <WriteWordGame words={words} />
              </div>
            )}
            {currentPage === 'game-quiz' && (
              <div className="animate-fade-in">
                <QuizGame words={words} />
              </div>
            )}
            {currentPage === 'flash-card' && (
              <div className="animate-fade-in">
                <FlashCardView words={words} />
              </div>
            )}
            {currentPage === 'notes' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Ghi chú & ôn tập</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'levels' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Học theo cấp độ</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'roadmap' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Theo lộ trình</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'stats' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Thống kê</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'reminder' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Nhắc nhở</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'sync' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Đồng bộ dữ liệu</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'account' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Tài khoản</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'export' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Xuất từ vựng</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
            {currentPage === 'import' && (
              <div className="bg-white rounded-2xl shadow p-8 text-center text-pastel-navy animate-fade-in">
                <div className="text-2xl font-bold mb-2">Nhập từ vựng</div>
                <div>Chức năng đang phát triển...</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;