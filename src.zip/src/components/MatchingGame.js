import React, { useEffect, useState } from 'react';
import { shuffle } from 'lodash';

export default function MatchingGame({ words, onFinish }) {
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState([]);
  const [matchedCount, setMatchedCount] = useState(0);
  const [wrongIds, setWrongIds] = useState([]);

  useEffect(() => {
    const createShuffledItems = () => {
      const wordCards = words.map((w) => ({
        id: `${w.id}-w`,
        matchId: w.id,
        text: w.word,
        type: 'word',
        matched: false,
      }));

      const meaningCards = words.map((w) => ({
        id: `${w.id}-m`,
        matchId: w.id,
        text: w.meaning,
        type: 'meaning',
        matched: false,
      }));

      const allCards = shuffle([...wordCards, ...meaningCards]);
      setItems(allCards);
    };

    createShuffledItems();
  }, [words]);

  const handleSelect = (item) => {
    if (item.matched || selected.find((s) => s.id === item.id)) return;

    const newSelected = [...selected, item];
    setSelected(newSelected);

    if (newSelected.length === 2) {
      const [a, b] = newSelected;
      const isCorrect = a.matchId === b.matchId && a.type !== b.type;

      if (isCorrect) {
        setItems((prev) =>
          prev.map((i) =>
            i.matchId === a.matchId ? { ...i, matched: true } : i
          )
        );
        setMatchedCount((c) => c + 1);
        setSelected([]);
      } else {
        setWrongIds([a.id, b.id]);
        setTimeout(() => {
          setSelected([]);
          setWrongIds([]);
          setItems((prev) => shuffle(prev)); // xáo lại vị trí
        }, 1000);
      }
    }
  };

  const playAudio = (audioUrl) => {
    if (
      audioUrl &&
      typeof audioUrl === 'string' &&
      /^https?:\/\/.+\.(mp3|wav|ogg)(\?.*)?$/i.test(audioUrl)
    ) {
      new Audio(audioUrl).play();
    }
  };

  const isComplete = matchedCount >= words.length;

  useEffect(() => {
    if (isComplete && typeof onFinish === 'function') {
      onFinish(`Đã nối đúng ${matchedCount}/${words.length} cặp từ`);
    }
  }, [isComplete, matchedCount, words.length, onFinish]);

  if (words.length === 0) return <div className="text-center text-gray-500">Chưa có từ vựng.</div>;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-center text-pastel-navy">🔗 Ghép từ & nghĩa</h2>

      {isComplete ? (
        <div className="text-center text-green-600 font-semibold text-xl">
          🎉 Hoàn thành! Bạn đã nối đúng {matchedCount} cặp từ vựng!
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {items.map((item) => {
            const isSelected = selected.find((s) => s.id === item.id);
            const isWrong = wrongIds.includes(item.id);

            return (
              <button
                key={item.id}
                disabled={item.matched}
                onClick={() => handleSelect(item)}
                className={`p-4 rounded-lg shadow text-center font-semibold border transition-all duration-300
                  ${item.matched ? 'bg-gray-200 text-gray-400 cursor-default' :
                    isWrong ? 'bg-red-200 border-red-400' :
                      isSelected ? 'bg-yellow-200 border-yellow-500' :
                        'bg-white hover:bg-blue-100 border-blue-300'}
                `}
              >
                {item.text}
              </button>
            );
          })}
        </div>
      )}

      <div className="text-center text-gray-500">
        Đã nối đúng: {matchedCount}/{words.length}
      </div>
    </div>
  );
}