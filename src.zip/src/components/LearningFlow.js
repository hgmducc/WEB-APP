import { useState } from 'react';
import FlashCardView from './FlashCardView';
import MatchingGame from './MatchingGame';
import QuizGame from './QuizGame';
import FillInTheBlankGame from './FillInTheBlankGame';
import WriteWordGame from './WriteWordGame';
import { FaChevronLeft, FaChevronRight, FaCheckCircle, FaRedo } from 'react-icons/fa';

const GAME_FLOW = [
  { key: 'flashcard', label: 'Flash Card', component: FlashCardView },
  { key: 'matching', label: 'Nối từ', component: MatchingGame },
  { key: 'quiz', label: 'Trắc nghiệm', component: QuizGame },
  { key: 'fill', label: 'Điền từ thiếu', component: FillInTheBlankGame },
  { key: 'write', label: 'Viết lại', component: WriteWordGame }
];

export default function LearningFlow({ words, onFinish }) {
  const [step, setStep] = useState(0);
  const [results, setResults] = useState([]);
  const [finished, setFinished] = useState(false);

  const handleGameFinish = (result) => {
    setResults(prev => {
      const updated = [...prev];
      updated[step] = result;
      return updated;
    });
    if (step + 1 < GAME_FLOW.length) {
      setStep(step + 1);
    } else {
      setFinished(true);
      if (typeof onFinish === 'function') onFinish(results.concat(result));
    }
  };

  const handleSkip = () => {
    setResults(prev => {
      const updated = [...prev];
      updated[step] = 'Đã bỏ qua';
      return updated;
    });
    if (step + 1 < GAME_FLOW.length) setStep(step + 1);
    else setFinished(true);
  };

  const handlePrev = () => {
    if (step > 0) setStep(step - 1);
  };

  const handleRestart = () => {
    setStep(0);
    setResults([]);
    setFinished(false);
  };

  const CurrentGame = GAME_FLOW[step]?.component;

  if (!words || words.length === 0) {
    return <div className="text-center text-gray-500 py-8">Chưa có từ vựng để học.</div>;
  }

  if (finished || !CurrentGame) {
    return (
      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow p-8 text-center space-y-4 animate-fade-in">
        <FaCheckCircle className="mx-auto text-4xl text-green-500 mb-2" />
        <h2 className="text-2xl font-bold text-green-600 mb-2">🎉 Hoàn thành buổi học!</h2>
        <ul className="text-left text-gray-700 space-y-1">
          {GAME_FLOW.map((g, i) => (
            <li key={g.key}>
              <span className="font-semibold">{i + 1}. {g.label}:</span> {results[i] || 'Đã hoàn thành'}
            </li>
          ))}
        </ul>
        <button
          className="mt-6 px-6 py-2 bg-blue-500 text-white rounded-full shadow hover:bg-blue-600 flex items-center gap-2 mx-auto"
          onClick={handleRestart}
        >
          <FaRedo /> Học lại từ đầu
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg p-6 md:p-10 space-y-4 animate-fade-in">
      <div className="flex items-center justify-between mb-2">
        <button
          className="text-blue-500 hover:text-blue-700 disabled:opacity-40"
          onClick={handlePrev}
          disabled={step === 0}
          title="Quay lại"
        >
          <FaChevronLeft size={22} />
        </button>
        <div className="text-lg font-semibold text-pastel-navy">
          Bước {step + 1}/{GAME_FLOW.length}: {GAME_FLOW[step].label}
        </div>
        <button
          className="text-gray-400 cursor-default"
          disabled
          style={{ visibility: 'hidden' }}
        >
          <FaChevronRight size={22} />
        </button>
      </div>
      <div className="w-full border-b border-gray-200 mb-4" />
      <div>
        <CurrentGame words={words} onFinish={handleGameFinish} />
      </div>
      <div className="flex justify-between mt-4">
        <button
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 transition"
          onClick={handleSkip}
        >
          Bỏ qua bước này
        </button>
        <div className="text-sm text-gray-500">
          Tiến trình: {step + 1}/{GAME_FLOW.length}
        </div>
      </div>
    </div>
  );
}
