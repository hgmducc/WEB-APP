// ✅ AddWordForm.js (hoàn chỉnh, không dùng addLocalWord, dùng wordExists)
import { useState } from 'react';
import { FaPlus } from 'react-icons/fa';

export default function AddWordForm({ onAdd, fetchIPAAndAudioOnly, wordExists }) {
  const [newWord, setNewWord] = useState({
    word: '', meaning: '', group: '',
    synonyms: '', examples: '', note: ''
  });
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (loading) return;
    if (!newWord.word.trim() || !newWord.meaning.trim()) {
      alert('Vui lòng nhập từ và nghĩa');
      return;
    }

    if (wordExists(newWord.word, newWord.meaning)) {
      alert('Từ đã tồn tại trong danh sách!');
      return;
    }

    setLoading(true);

    // Gọi API lấy IPA và audio trước khi lưu vào Firestore
    const { ipa, audioUrl } = await fetchIPAAndAudioOnly(newWord.word);

    // Chuẩn hóa dữ liệu synonyms/examples thành mảng
    const wordToAdd = {
      ...newWord,
      synonyms: newWord.synonyms
        ? newWord.synonyms.split(',').map(s => s.trim()).filter(Boolean)
        : [],
      examples: newWord.examples
        ? newWord.examples.split('|').map(e => e.trim()).filter(Boolean)
        : [],
      note: newWord.note || '',
      ipa,
      audioUrl,
      level: 'weak',
      favorite: false,
    };

    const id = await onAdd(wordToAdd);
    if (!id) {
      alert('Không thể lưu từ vào hệ thống.');
    }

    setNewWord({
      word: '', meaning: '', group: '',
      synonyms: '', examples: '', note: ''
    });
    setLoading(false);
  };

  return (
    <div className="bg-white rounded-2xl p-4 md:p-6 shadow-md space-y-4 mb-8 border border-pastel-blue">
      <div className="flex justify-between items-center">
        <h2 className="font-semibold text-lg md:text-xl text-pastel-green flex items-center gap-2">
          <FaPlus /> Thêm từ vựng mới
        </h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <input
          type="text"
          placeholder="Từ"
          value={newWord.word}
          onChange={e => setNewWord({ ...newWord, word: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          onKeyDown={e => e.key === 'Enter' && handleAdd()}
          disabled={loading}
        />
        <input
          type="text"
          placeholder="Nghĩa"
          value={newWord.meaning}
          onChange={e => setNewWord({ ...newWord, meaning: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          onKeyDown={e => e.key === 'Enter' && handleAdd()}
          disabled={loading}
        />
        <input
          type="text"
          placeholder="Nhóm"
          value={newWord.group}
          onChange={e => setNewWord({ ...newWord, group: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          onKeyDown={e => e.key === 'Enter' && handleAdd()}
          disabled={loading}
        />
        <input
          type="text"
          placeholder="Từ đồng nghĩa (phẩy , ngăn cách)"
          value={newWord.synonyms}
          onChange={e => setNewWord({ ...newWord, synonyms: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          disabled={loading}
        />
        <input
          type="text"
          placeholder="Ví dụ (| ngăn cách)"
          value={newWord.examples}
          onChange={e => setNewWord({ ...newWord, examples: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          disabled={loading}
        />
        <input
          type="text"
          placeholder="Ghi chú"
          value={newWord.note}
          onChange={e => setNewWord({ ...newWord, note: e.target.value })}
          className="px-4 py-2 border border-pastel-pink rounded-lg focus:outline-none"
          disabled={loading}
        />
        <button
          onClick={handleAdd}
          disabled={loading}
          className={`bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 hover:brightness-110 text-white px-4 py-2 rounded-full font-semibold shadow-lg transition duration-300
            ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {loading ? 'Đang thêm...' : '➕ Thêm'}
        </button>
      </div>
    </div>
  );
}