import { useState, useRef, useEffect } from 'react';

// So sánh chính tả, trả về mảng ký tự với lỗi in đỏ
function diffChars(correct, input) {
  const res = [];
  for (let i = 0; i < Math.max(correct.length, input.length); i++) {
    if (input[i] === correct[i]) {
      res.push(<span key={i} className="text-green-600 font-bold">{input[i]}</span>);
    } else if (input[i]) {
      res.push(<span key={i} className="text-red-600 font-bold">{input[i]}</span>);
    } else {
      res.push(<span key={i} className="text-gray-400">_</span>);
    }
  }
  return res;
}

function getHint(word, tries, meaning, synonyms) {
  if (tries === 2) return `Ký tự đầu: ${word[0]}`;
  if (tries === 3) return `Độ dài: ${word.length} ký tự`;
  if (tries === 4 && synonyms?.length) return `Từ liên quan: ${synonyms[0]}`;
  if (tries >= 5) return `Tiếp theo: ${word.slice(0, tries - 1)}`;
  return '';
}

export default function WriteWordGame({ words, topics, onFinish }) {
  const [mode, setMode] = useState('en-vi');
  const [autoHint, setAutoHint] = useState(true);
  const [idx, setIdx] = useState(0);
  const [input, setInput] = useState('');
  const [tries, setTries] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [hint, setHint] = useState('');
  const [done, setDone] = useState(false);

  const inputRef = useRef();

  const current = words[idx];

  let ask, answer, synonyms;
  if (!current) {
    ask = answer = '';
    synonyms = [];
  } else if (mode === 'en-vi') {
    ask = current.word;
    answer = current.meaning;
    synonyms = current.synonyms || [];
  } else {
    ask = current.meaning;
    answer = current.word;
    synonyms = current.synonyms || [];
  }

  useEffect(() => {
    if (done && typeof onFinish === 'function') {
      onFinish(`Đã hoàn thành viết lại ${words.length} từ.`);
    }
  }, [done, words.length, onFinish]);

  function checkAnswer() {
    if (!input.trim()) return;
    const correct = input.trim().toLowerCase() === answer.trim().toLowerCase();
    if (correct) {
      setIdx(idx + 1);
      setInput('');
      setTries(0);
      setShowAnswer(false);
      setHint('');
      if (idx + 1 >= words.length) setDone(true);
    } else {
      if (!autoHint) {
        setShowAnswer(true);
        setTries(1);
        setHint('');
      } else {
        if (tries + 1 >= 4) setShowAnswer(true);
        else if (autoHint && tries + 1 >= 2) setHint(getHint(answer, tries + 1, current.meaning, synonyms));
        setTries(tries + 1);
      }
    }
  }

  function handleInput(e) {
    setInput(e.target.value);
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') checkAnswer();
  }

  function handleShowAnswer() {
    setShowAnswer(true);
    setTries(5);
    setHint('');
  }

  function handleContinue() {
    setIdx(idx + 1);
    setInput('');
    setTries(0);
    setShowAnswer(false);
    setHint('');
    if (idx + 1 >= words.length) setDone(true);
  }

  function handleRestart() {
    setIdx(0);
    setInput('');
    setTries(0);
    setShowAnswer(false);
    setHint('');
    setDone(false);
  }

  if (!words || words.length < 1)
    return <div className="text-center text-gray-500 py-8">Chưa có từ vựng.</div>;

  if (done) {
    return (
      <div className="max-w-lg mx-auto bg-gradient-to-br from-indigo-200 to-blue-300 rounded-3xl shadow-2xl p-10 text-center animate-fade-in">
        <h2 className="text-3xl font-extrabold text-blue-800 mb-4">🎉 Hoàn thành buổi học!</h2>
        <p className="text-xl text-blue-700 mb-6">Bạn đã học {words.length} từ.</p>
        <button
          className="px-6 py-3 bg-indigo-600 text-white text-lg rounded-xl shadow-md hover:bg-indigo-700 transition-transform hover:scale-105"
          onClick={handleRestart}
        >
          🔄 Học lại từ đầu
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto bg-gradient-to-br from-white to-slate-50 rounded-3xl shadow-2xl p-8 space-y-6 animate-fade-in">
      {/* Settings */}
      <div className="flex flex-wrap gap-4 justify-center items-center">
        <select
          value={mode}
          onChange={e => setMode(e.target.value)}
          className="border border-gray-300 rounded-xl px-4 py-2 text-gray-700 shadow-sm focus:ring focus:ring-indigo-200"
        >
          <option value="en-vi">Tiếng Anh → Nghĩa tiếng Việt</option>
          <option value="vi-en">Tiếng Việt → Viết từ tiếng Anh</option>
        </select>

        <label className="flex items-center space-x-2 text-gray-700">
          <input
            type="checkbox"
            checked={autoHint}
            onChange={e => setAutoHint(e.target.checked)}
            className="rounded border-gray-300"
          />
          <span>Gợi ý tự động</span>
        </label>
      </div>

      {/* Progress */}
      <div className="text-center text-lg font-medium text-indigo-800">
        Tiến độ: {idx + 1}/{words.length}
      </div>

      {/* Question */}
      <div className="text-center text-2xl md:text-3xl font-extrabold text-indigo-900 p-4 bg-indigo-100 rounded-xl shadow-inner transition-all duration-300">
        {mode === 'en-vi' ? `Từ: ${ask}` : `Nghĩa: ${ask}`}
      </div>

      {/* Input */}
      <input
        ref={inputRef}
        className="w-full border border-gray-300 rounded-xl px-5 py-4 text-xl text-indigo-900 shadow-inner focus:ring focus:ring-indigo-300 transition-all"
        placeholder="Nhập đáp án..."
        value={input}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        disabled={showAnswer}
        autoFocus
      />

      {/* Answer */}
      {showAnswer && (
        <div className="text-center text-red-600 text-lg font-semibold space-y-2 transition-all animate-fade-in">
          <div>Đáp án đúng: <span className="font-bold">{answer}</span></div>
          {mode === 'vi-en' && (
            <div className="mt-1">So sánh: {diffChars(answer, input)}</div>
          )}
          {Array.isArray(current.synonyms) && current.synonyms.length > 0 && (
            <div className="text-blue-700 text-base">
              <span className="font-semibold">Từ đồng nghĩa:</span> {current.synonyms.join(', ')}
            </div>
          )}
          {Array.isArray(current.examples) && current.examples.length > 0 && (
            <div className="text-gray-600 text-sm">
              <span className="font-semibold">Ví dụ:</span>
              <ul className="list-disc ml-4">
                {current.examples.map((ex, i) => <li key={i}>{ex}</li>)}
              </ul>
            </div>
          )}
          {current.note && (
            <div className="text-purple-700 text-sm">
              <span className="font-semibold">Ghi chú:</span> {current.note}
            </div>
          )}
        </div>
      )}

      {/* Hint */}
      {hint && !showAnswer && (
        <div className="text-center text-blue-600 text-base italic animate-fade-in">
          💡 Gợi ý: {hint}
        </div>
      )}

      {/* Buttons */}
      <div className="flex gap-3">
        {!showAnswer && (
          <button
            className="flex-1 py-3 bg-indigo-500 text-white rounded-xl shadow hover:bg-indigo-600 transition-transform hover:scale-105"
            onClick={checkAnswer}
          >
            Kiểm tra
          </button>
        )}
        {showAnswer && (
          <button
            className="flex-1 py-3 bg-green-500 text-white rounded-xl shadow hover:bg-green-600 transition-transform hover:scale-105"
            onClick={handleContinue}
          >
            Từ tiếp theo
          </button>
        )}
        {autoHint && tries >= 4 && !showAnswer && (
          <button
            className="flex-1 py-3 bg-red-300 text-red-800 rounded-xl shadow hover:bg-red-400 transition-transform hover:scale-105"
            onClick={handleShowAnswer}
          >
            Xem đáp án
          </button>
        )}
      </div>
    </div>
  );
}