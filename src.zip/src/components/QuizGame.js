import { useState, useEffect } from 'react';

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

function getRandomSample(arr, n) {
  const copy = [...arr];
  const result = [];
  while (result.length < n && copy.length > 0) {
    const idx = getRandomInt(copy.length);
    result.push(copy[idx]);
    copy.splice(idx, 1);
  }
  return result;
}

// Sinh 1 câu hỏi ngẫu nhiên: hỏi từ hoặc nghĩa, 4 đáp án
function createQuestion(words) {
  const correct = words[getRandomInt(words.length)];
  const askWord = Math.random() < 0.5;
  let question, answer, options;
  if (askWord) {
    question = correct.word;
    answer = correct.meaning;
    const wrongs = getRandomSample(words.filter(w => w !== correct), 3).map(w => w.meaning);
    options = [answer, ...wrongs].sort(() => Math.random() - 0.5);
    return {
      type: 'word-meaning',
      question,
      options,
      answer,
    };
  } else {
    question = correct.meaning;
    answer = correct.word;
    const wrongs = getRandomSample(words.filter(w => w !== correct), 3).map(w => w.word);
    options = [answer, ...wrongs].sort(() => Math.random() - 0.5);
    return {
      type: 'meaning-word',
      question,
      options,
      answer,
    };
  }
}

export default function QuizGame({ words, onFinish }) {
  const canPlay = words.length >= 4;
  const [quiz, setQuiz] = useState(() => canPlay ? createQuestion(words) : null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (quiz === null && typeof onFinish === 'function') {
      onFinish('Đã hoàn thành trắc nghiệm.');
    }
  }, [quiz, onFinish]);

  if (!canPlay) {
    return <div className="text-pastel-navy">Cần ít nhất 4 từ để chơi trắc nghiệm.</div>;
  }

  const handleSelect = (opt) => {
    if (selected !== null) return;
    setSelected(opt);
  };

  const handleNext = () => {
    setQuiz(createQuestion(words));
    setSelected(null);
  };

  const optionLabels = ['A', 'B', 'C', 'D'];

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow p-4">
      <div className="text-lg font-semibold mb-4 text-pastel-navy text-center">
        {quiz.type === 'word-meaning'
          ? <>Từ: <span className="italic">{quiz.question}</span></>
          : <>Nghĩa: <span className="italic">{quiz.question}</span></>
        }
      </div>
      <div className="grid grid-cols-1 gap-3 mb-4">
        {quiz.options.map((opt, idx) => {
          let btnClass = "py-2 px-4 rounded-lg border transition flex items-center gap-2 justify-center";
          if (selected !== null) {
            if (opt === quiz.answer) btnClass += " bg-green-200 border-green-400";
            else if (opt === selected) btnClass += " bg-red-200 border-red-400";
            else btnClass += " bg-gray-100 border-gray-200";
          } else {
            btnClass += " bg-pastel-blue border-pastel-navy hover:bg-pastel-green";
          }
          return (
            <button
              key={idx}
              className={btnClass}
              disabled={selected !== null}
              onClick={() => handleSelect(opt)}
            >
              <span className="font-bold">{optionLabels[idx]}.</span> {opt}
            </button>
          );
        })}
      </div>
      {selected !== null && (
        <button
          className="w-full py-2 bg-blue-600 text-white rounded-lg shadow-md font-semibold uppercase hover:bg-blue-700 transition-all"
          onClick={handleNext}
        >
          Câu tiếp
        </button>
      )}
    </div>
  );
}