// ✅ WordTable.js
import React, { useState } from 'react';
import { FaTrash, FaHeart, FaRegHeart, FaVolumeUp } from 'react-icons/fa';

const WordTable = ({ words, onToggleFavorite, onDelete, onUpdateIPA }) => {
  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState('');
  const [editingIPAId, setEditingIPAId] = useState(null);
  const [ipaInput, setIpaInput] = useState('');

  const playAudio = (audioUrl) => {
    if (
      audioUrl &&
      typeof audioUrl === 'string' &&
      /^https?:\/\/.+\.(mp3|wav|ogg)(\?.*)?$/i.test(audioUrl)
    ) {
      new Audio(audioUrl).play();
    } else {
      alert("Không có phát âm hợp lệ");
    }
  };

  const filteredWords = words.filter(word => {
    const matchesSearch = word.word.toLowerCase().includes(search.toLowerCase()) ||
                          word.meaning.toLowerCase().includes(search.toLowerCase());
    const matchesGroup = groupFilter ? word.group === groupFilter : true;
    const matchesLevel = levelFilter ? word.level === levelFilter : true;
    return matchesSearch && matchesGroup && matchesLevel;
  });

  const uniqueGroups = [...new Set(words.map(w => w.group))];
  const uniqueLevels = [...new Set(words.map(w => w.level))];

  const handleEditIPA = (word) => {
    setEditingIPAId(word.id);
    setIpaInput(word.ipa || '');
  };

  const handleSaveIPA = (id) => {
    onUpdateIPA(id, ipaInput.trim());
    setEditingIPAId(null);
    setIpaInput('');
  };

  const handleCancelIPA = () => {
    setEditingIPAId(null);
    setIpaInput('');
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex flex-wrap gap-4 items-center">
        <input
          type="text"
          placeholder="Tìm kiếm từ hoặc nghĩa..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md w-full md:w-1/3"
        />
        <select
          value={groupFilter}
          onChange={e => setGroupFilter(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        >
          <option value="">Tất cả nhóm</option>
          {uniqueGroups.map(g => <option key={g} value={g}>{g}</option>)}
        </select>
        <select
          value={levelFilter}
          onChange={e => setLevelFilter(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md"
        >
          <option value="">Tất cả mức độ</option>
          {uniqueLevels.map(l => <option key={l} value={l}>{l}</option>)}
        </select>
      </div>

      <div className="overflow-x-auto shadow-md rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full table-auto text-sm">
          <thead className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
            <tr>
              {['#', 'Từ tiếng Anh', 'Nghĩa', 'Phiên âm IPA', 'Phát âm', 'Mức độ', 'Nhóm', 'Yêu thích', 'Xoá', 'Từ đồng nghĩa', 'Ví dụ', 'Ghi chú'].map((h, i) => (
                <th key={i} className="px-4 py-3 text-left whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredWords.map((word, index) => (
              <tr key={word.id} className="hover:bg-blue-50 transition">
                <td className="px-4 py-3 font-medium">{index + 1}</td>
                <td className="px-4 py-3">{word.word}</td>
                <td className="px-4 py-3">{word.meaning}</td>
                <td className="px-4 py-3">
                  {editingIPAId === word.id ? (
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={ipaInput}
                        onChange={e => setIpaInput(e.target.value)}
                        className="border border-gray-300 rounded px-2 py-1 text-sm w-full"
                      />
                      <button
                        onClick={() => handleSaveIPA(word.id)}
                        className="text-green-600 hover:text-green-800 font-bold"
                        title="Lưu"
                      >
                        ✔
                      </button>
                      <button
                        onClick={handleCancelIPA}
                        className="text-red-600 hover:text-red-800 font-bold"
                        title="Hủy"
                      >
                        ✘
                      </button>
                    </div>
                  ) : (
                    <span
                      className="cursor-pointer hover:underline text-gray-700"
                      onClick={() => handleEditIPA(word)}
                      title="Nhấn để sửa phiên âm IPA"
                    >
                      {word.ipa || <i className="text-gray-400">Chưa có</i>}
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => playAudio(word.audioUrl)} className="text-blue-500 hover:text-blue-700">
                    <FaVolumeUp />
                  </button>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2 py-1 rounded-full font-semibold 
                    ${word.level === "strong" ? "bg-green-100 text-green-700" :
                      word.level === "medium" ? "bg-yellow-100 text-yellow-700" :
                      "bg-red-100 text-red-700"}`}>
                    {word.level}
                  </span>
                </td>
                <td className="px-4 py-3 capitalize">{word.group}</td>
                <td className="px-4 py-3">
                  <button onClick={() => onToggleFavorite(word.id)} className="text-pink-500 hover:text-pink-700">
                    {word.favorite ? <FaHeart /> : <FaRegHeart />}
                  </button>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => onDelete(word.id)} className="text-red-500 hover:text-red-700">
                    <FaTrash />
                  </button>
                </td>
                <td className="px-4 py-3">
                  {Array.isArray(word.synonyms) && word.synonyms.length > 0
                    ? word.synonyms.join(', ')
                    : <span className="text-gray-400 italic">-</span>}
                </td>
                <td className="px-4 py-3">
                  {Array.isArray(word.examples) && word.examples.length > 0
                    ? word.examples.map((ex, i) => (
                        <div key={i} className="text-gray-700">• {ex}</div>
                      ))
                    : <span className="text-gray-400 italic">-</span>}
                </td>
                <td className="px-4 py-3">
                  {word.note ? word.note : <span className="text-gray-400 italic">-</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WordTable;
