// components/SidebarMenu.js
import {
  FaBook, FaClock, FaFolder, FaStickyNote, FaSignal, FaRoute,
  FaPencilAlt, FaQuestion, FaLink, FaChartBar, FaUser, FaCloudUploadAlt, FaBell, FaFileImport, FaFileExport, FaSync
} from 'react-icons/fa';

const menuSections = [
  {
    label: 'Học & Ôn tập',
    items: [
      { label: 'Tổng quan', key: 'dashboard', icon: <FaChartBar /> },
      { label: 'Học liền mạch', key: 'learningflow', icon: <FaSync /> },
      { label: 'Flash Card', key: 'flash-card', icon: <FaQuestion /> },
      { label: 'Nối từ', key: 'game-match', icon: <FaLink /> },
      { label: 'Trắc nghiệm', key: 'game-quiz', icon: <FaQuestion /> },
      { label: 'Điền từ thiếu', key: 'game-fill', icon: <FaPencilAlt /> },
      { label: 'Viết lại', key: 'game-write', icon: <FaPencilAlt /> },
      { label: 'Lặp lại ngắt quãng', key: 'spaced', icon: <FaClock /> },
      { label: 'Theo chủ đề', key: 'topics', icon: <FaFolder /> },
      { label: 'Ghi chú & Ôn tập', key: 'notes', icon: <FaStickyNote /> },
      { label: 'Theo cấp độ', key: 'levels', icon: <FaSignal /> },
      { label: 'Theo lộ trình', key: 'roadmap', icon: <FaRoute /> }
    ]
  },
  {
    label: 'Quản lý từ vựng',
    items: [
      { label: 'Bảng từ vựng', key: 'vocab', icon: <FaBook /> },
      { label: 'Xuất từ vựng', key: 'export', icon: <FaFileExport /> },
      { label: 'Nhập từ vựng', key: 'import', icon: <FaFileImport /> }
    ]
  },
  {
    label: 'Thống kê & Nhắc nhở',
    items: [
      { label: 'Thống kê', key: 'stats', icon: <FaChartBar /> },
      { label: 'Nhắc nhở', key: 'reminder', icon: <FaBell /> }
    ]
  },
  {
    label: 'Tài khoản',
    items: [
      { label: 'Đồng bộ dữ liệu', key: 'sync', icon: <FaCloudUploadAlt /> },
      { label: 'Tài khoản', key: 'account', icon: <FaUser /> }
    ]
  }
];

export default function SidebarMenu({ onSelect, currentPage }) {
  return (
    <div className="flex flex-col h-full bg-white p-4 font-inter overflow-y-auto">
      <div className="text-3xl font-extrabold text-pastel-navy mb-8 flex items-center gap-2 justify-center tracking-tight drop-shadow">
        <span className="bg-gradient-to-r from-pastel-blue to-pastel-pink px-3 py-1 rounded-2xl shadow">VOCAB</span>
      </div>
      <div className="space-y-6">
        {menuSections.map(section => (
          <div key={section.label}>
            <div className="text-xs uppercase font-bold text-pastel-navy mb-2 pl-2 tracking-widest">{section.label}</div>
            <div className="space-y-1">
              {section.items.map(item => (
                <button
                  key={item.key}
                  className={`w-full text-left px-4 py-2 rounded-xl transition flex items-center gap-3 font-medium
                    ${currentPage === item.key
                      ? 'bg-pastel-blue text-pastel-navy shadow font-bold'
                      : 'hover:bg-pastel-blue/60 text-gray-700'}
                  `}
                  onClick={() => onSelect(item.key)}
                >
                  {item.icon} {item.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
