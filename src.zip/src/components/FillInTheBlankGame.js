import { useState, useMemo, useEffect } from 'react';
import { FaArrowRight, FaVolumeUp } from 'react-icons/fa';
import { db } from '../firebase';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';

const MASK_LEVELS = [0.95, 0.75, 0.5, 0.25, 1.0]; // ⬅ Thêm 1.0: ẩn toàn bộ

function generateMasked(word, maskIndices) {
  return word
    .split('')
    .map((char, i) => (maskIndices.includes(i) ? '_' : char))
    .join('');
}

function getRandomMaskIndices(word, ratio) {
  const length = word.length;
  const numToHide = Math.max(1, Math.floor(length * ratio));
  const indices = new Set();
  while (indices.size < numToHide) {
    const i = Math.floor(Math.random() * length);
    if (/[a-zA-Z]/.test(word[i])) {
      indices.add(i);
    }
  }
  return Array.from(indices);
}

function shuffleArray(array) {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export default function FillInTheBlankGame({ words, onFinish }) {
  const [queue, setQueue] = useState(() => shuffleArray(words));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userInput, setUserInput] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [difficultyMap, setDifficultyMap] = useState(() => new Map(words.map(w => [w.word, 0]))); // 0: easiest
  const [maskMap, setMaskMap] = useState(new Map());
  const [wrongWords, setWrongWords] = useState([]);

  const current = queue[currentIndex];
  const currentLevel = difficultyMap.get(current.word) ?? 0;
  const currentRatio = MASK_LEVELS[currentLevel];

  const maskIndices = useMemo(() => {
    if (!maskMap.has(current.word)) {
      const newIndices = getRandomMaskIndices(current.word, currentRatio);
      setMaskMap(prev => new Map(prev).set(current.word, newIndices));
      return newIndices;
    }
    return maskMap.get(current.word);
  }, [current, currentRatio, maskMap]);

  const masked = useMemo(
    () => generateMasked(current.word.toUpperCase(), maskIndices),
    [current, maskIndices]
  );

  const handleSubmit = async () => {
    const correct = userInput.trim().toLowerCase() === current.word.toLowerCase();
    setIsCorrect(correct);
    setShowResult(true);

    // Ghi kết quả vào Firebase
    await addDoc(collection(db, 'word_history'), {
      wordId: current.id || '',
      word: current.word,
      status: correct ? 'known' : 'unknown',
      createdAt: serverTimestamp(),
    });

    setDifficultyMap(prev => {
      const newMap = new Map(prev);
      const level = newMap.get(current.word) ?? 0;
      if (correct) {
        newMap.set(current.word, 0); // về dễ nhất
      } else {
        const newLevel = Math.min(level + 1, MASK_LEVELS.length - 1);
        newMap.set(current.word, newLevel);
        setWrongWords(prev => [...new Set([...prev, current])]);
      }
      return newMap;
    });

    // Nếu sai: giữ lại cuối danh sách
    if (!correct) {
      setQueue(prev => [...prev.slice(0, currentIndex + 1), ...prev.slice(currentIndex + 1), current]);
    }
  };

  const handleNext = () => {
    setUserInput('');
    setShowResult(false);
    setIsCorrect(false);

    setMaskMap(prev => {
      const newMap = new Map(prev);
      newMap.delete(current.word);
      return newMap;
    });

    setCurrentIndex(prev => (prev + 1 < queue.length ? prev + 1 : 0));
  };

  const resetWithWrongWords = () => {
    setQueue(shuffleArray(wrongWords));
    setWrongWords([]);
    setCurrentIndex(0);
    setUserInput('');
    setShowResult(false);
    setIsCorrect(false);
    setMaskMap(new Map());
  };

  const learned = currentIndex + (showResult ? 1 : 0);

  useEffect(() => {
    if (queue.length === 0 && typeof onFinish === 'function') {
      onFinish('Đã hoàn thành bài điền từ.');
    }
  }, [queue.length, onFinish]);

  if (!current) return <div className="text-center text-gray-600">Không có từ nào để hiển thị.</div>;

  return (
    <div className="p-6 bg-white shadow-md rounded-xl max-w-xl mx-auto space-y-6 border border-pastel-blue">
      <h2 className="text-xl font-bold text-pastel-navy text-center">📝 Viết Lại Từ</h2>

      <div className="text-center text-lg">
        Nghĩa: <span className="font-medium">{current.meaning}</span>
      </div>

      {current.audioUrl && (
        <div className="text-center">
          <button
            onClick={() => new Audio(current.audioUrl).play()}
            className="text-blue-600 hover:text-blue-800 text-xl mb-2"
            title="Phát âm"
          >
            <FaVolumeUp />
          </button>
        </div>
      )}

      <div className="text-center text-2xl font-bold tracking-widest text-blue-600">{masked}</div>

      <input
        type="text"
        placeholder="Nhập từ hoàn chỉnh..."
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
        className="w-full px-4 py-2 border border-gray-300 rounded-md"
        onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
      />

      {!showResult ? (
        <button
          onClick={handleSubmit}
          className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg font-semibold flex justify-center items-center gap-2"
        >
          Kiểm tra <FaArrowRight />
        </button>
      ) : (
        <div className="text-center">
          <div className={`font-semibold ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
            {isCorrect ? '✅ Chính xác!' : `❌ Sai rồi. Đáp án: ${current.word}`}
          </div>
          <button
            onClick={handleNext}
            className="mt-4 bg-pastel-green hover:bg-green-400 text-white py-2 px-4 rounded-full font-medium"
          >
            Từ tiếp theo
          </button>
        </div>
      )}

      <p className="text-sm text-gray-500 text-center">
        Đã học: {learned}/{queue.length}
      </p>

      {queue.length === 1 && wrongWords.length > 0 && (
        <div className="text-center mt-4">
          <button
            onClick={resetWithWrongWords}
            className="bg-purple-500 text-white px-6 py-2 rounded-full hover:bg-purple-600"
          >
            🔁 Luyện lại từ sai ({wrongWords.length})
          </button>
        </div>
      )}
    </div>
  );
}