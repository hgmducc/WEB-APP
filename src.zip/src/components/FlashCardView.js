import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { FaVolumeUp, FaArrowLeft, FaArrowRight, FaSync } from 'react-icons/fa';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default function FlashCardView({ words, onFinish }) {
  const [remainingWords, setRemainingWords] = useState(words);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [learnedCount, setLearnedCount] = useState(0);

  const currentWord = useMemo(() => remainingWords[index] || {}, [remainingWords, index]);

  const playAudio = useCallback(() => {
    if (
      currentWord.audioUrl &&
      typeof currentWord.audioUrl === 'string' &&
      /^https?:\/\/.+\.(mp3|wav|ogg)(\?.*)?$/i.test(currentWord.audioUrl)
    ) {
      new Audio(currentWord.audioUrl).play();
    }
  }, [currentWord.audioUrl]);

  const markStatus = useCallback(async (word, status) => {
    if (!word || !word.word) return; // Không ghi nếu thiếu dữ liệu
    await addDoc(collection(db, 'word_history'), {
      wordId: word.id || '',
      word: word.word,
      status,
      createdAt: serverTimestamp(),
    });
  }, []);

  const next = useCallback((isKnown) => {
    const newList = [...remainingWords];
    if (isKnown) {
      newList.splice(index, 1);
      setLearnedCount((c) => c + 1);
    } else {
      setIndex((prev) => (prev + 1 >= newList.length ? 0 : prev + 1));
    }

    setRemainingWords(newList);
    setFlipped(false);
    setIndex((prev) => {
      if (newList.length === 0) return 0;
      return Math.min(prev, newList.length - 1);
    });
  }, [index, remainingWords]);

  const handleKey = useCallback((e) => {
    if (e.code === 'Space' || e.code === 'Enter') {
      e.preventDefault();
      setFlipped(prev => !prev);
    } else if (e.code === 'ArrowLeft') {
      markStatus(currentWord, 'unknown');
      next(false);
    } else if (e.code === 'ArrowRight') {
      markStatus(currentWord, 'known');
      next(true);
    }
  }, [currentWord, markStatus, next]);

  useEffect(() => {
    if (!flipped && currentWord.audioUrl) {
      playAudio();
    }
  }, [index, flipped, currentWord.audioUrl, playAudio]);

  useEffect(() => {
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [handleKey]);

  useEffect(() => {
    if (remainingWords.length === 0 && typeof onFinish === 'function') {
      onFinish(`Đã học ${learnedCount}/${words.length} từ`);
    }
  }, [remainingWords, learnedCount, words.length, onFinish]);

  const resetSession = () => {
    setRemainingWords(words);
    setIndex(0);
    setFlipped(false);
    setLearnedCount(0);
  };

  if (words.length === 0) return <p className="text-center text-gray-500">Chưa có từ vựng.</p>;

  if (remainingWords.length === 0) {
    return (
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold text-green-600">🎉 Bạn đã hoàn thành buổi học!</h2>
        <p className="text-gray-600">Đã học {learnedCount}/{words.length} từ.</p>
        <button
          onClick={resetSession}
          className="px-6 py-2 bg-blue-500 text-white rounded-full shadow hover:bg-blue-600"
        >
          🔁 Làm lại từ đầu
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] space-y-6">
      <div className="[perspective:1500px]">
        <div onClick={() => setFlipped(!flipped)} className="relative w-80 h-52 cursor-pointer">
          <div
            className="absolute w-full h-full transition-transform duration-700 ease-in-out rounded-3xl"
            style={{
              transformStyle: 'preserve-3d',
              transform: flipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
            }}
          >
            {/* Front side */}
            <div
              className="absolute w-full h-full flex items-center justify-center text-3xl font-bold text-blue-800 px-4 bg-white rounded-3xl shadow-lg border-2 border-blue-400"
              style={{ backfaceVisibility: 'hidden' }}
            >
              {currentWord.word}
            </div>

            {/* Back side */}
            <div
              className="absolute w-full h-full flex flex-col items-center justify-center text-2xl font-medium text-pink-700 px-4 bg-white rounded-3xl shadow-xl border-2 border-pink-400"
              style={{
                transform: 'rotateY(180deg)',
                backfaceVisibility: 'hidden',
              }}
            >
              <div>{currentWord.meaning}</div>
              {Array.isArray(currentWord.synonyms) && currentWord.synonyms.length > 0 && (
                <div className="text-sm text-blue-700 mt-2">
                  <span className="font-semibold">Từ đồng nghĩa:</span> {currentWord.synonyms.join(', ')}
                </div>
              )}
              {Array.isArray(currentWord.examples) && currentWord.examples.length > 0 && (
                <div className="text-xs text-gray-600 mt-1">
                  <span className="font-semibold">Ví dụ:</span>
                  <ul className="list-disc ml-4">
                    {currentWord.examples.map((ex, i) => (
                      <li key={i}>{ex}</li>
                    ))}
                  </ul>
                </div>
              )}
              {currentWord.note && (
                <div className="text-xs text-purple-700 mt-1">
                  <span className="font-semibold">Ghi chú:</span> {currentWord.note}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-4 text-2xl">
        <button
          onClick={() => {
            markStatus(currentWord, 'unknown');
            next(false);
          }}
          className="text-red-500 hover:text-red-700"
          title="Chưa nhớ (←)"
        >
          <FaArrowLeft />
        </button>
        <button onClick={resetSession} className="text-purple-500 hover:text-purple-700" title="Làm lại">
          <FaSync />
        </button>
        <button
          onClick={() => {
            markStatus(currentWord, 'known');
            next(true);
          }}
          className="text-green-500 hover:text-green-700"
          title="Đã nhớ (→)"
        >
          <FaArrowRight />
        </button>
        <button onClick={playAudio} className="text-pink-500 hover:text-pink-700" title="Phát âm lại">
          <FaVolumeUp />
        </button>
      </div>

      <p className="text-sm text-gray-500 text-center">
        Đã học: {learnedCount}/{words.length} từ
      </p>
      <p className="text-gray-500 text-sm text-center px-4">
        Nhấn <strong>Space</strong> hoặc <strong>Enter</strong> để lật thẻ, ← nếu chưa nhớ, → nếu đã nhớ.
      </p>
    </div>
  );
}