// components/Dashboard.js
import {
  PieChart, Pie, Cell, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  ResponsiveContainer
} from 'recharts';

function getTodayString() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function getDateString(date) {
  if (!date) return '';
  if (typeof date === 'string') return date.slice(0, 10);
  if (date.toDate) return date.toDate().toISOString().slice(0, 10);
  return new Date(date).toISOString().slice(0, 10);
}

export default function Dashboard({ words = [], getWordsForToday }) {
  // Thống kê số từ mới hôm nay
  const todayStr = getTodayString();
  const newWordsToday = words.filter(
    w => getDateString(w.createdAt) === todayStr
  ).length;

  // Số từ cần ôn hôm nay
  const reviewWords = getWordsForToday ? getWordsForToday() : [];
  const reviewCount = reviewWords.length;

  // Tổng số từ đã học
  const totalWords = words.length;

  // Thống kê số từ theo level
  const levelStats = {};
  words.forEach(w => {
    levelStats[w.level] = (levelStats[w.level] || 0) + 1;
  });

  // Pie chart: phân bố mức độ ghi nhớ
  const pieData = Object.entries(levelStats).map(([level, value]) => ({
    name: level,
    value
  }));
  const COLORS = ['#34d399', '#f87171', '#60a5fa', '#fbbf24', '#a78bfa', '#f472b6'];

  // Bar chart: số từ mới mỗi ngày trong 7 ngày gần nhất
  const days = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().slice(0, 10);
  });
  const barData = days.map(dateStr => ({
    name: dateStr.slice(5), // MM-DD
    'Từ mới': words.filter(w => getDateString(w.createdAt) === dateStr).length,
    'Ôn tập': words.filter(w =>
      getDateString(w.lastReviewedAt) === dateStr && w.level !== 'new'
    ).length
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-gray-800">
      <div className="bg-gradient-to-br from-pastel-blue to-pastel-green rounded-2xl p-6 shadow-lg flex flex-col items-center">
        <div className="text-4xl mb-2">📅</div>
        <h2 className="font-bold text-lg mb-1">Từ mới hôm nay</h2>
        <div className="text-2xl font-extrabold text-pastel-navy mb-2">{newWordsToday}</div>
        <div className="text-sm text-gray-500">Từ mới đã thêm hôm nay</div>
      </div>
      <div className="bg-gradient-to-br from-pastel-pink to-pastel-blue rounded-2xl p-6 shadow-lg flex flex-col items-center">
        <div className="text-4xl mb-2">⏰</div>
        <h2 className="font-bold text-lg mb-1">Cần ôn hôm nay</h2>
        <div className="text-2xl font-extrabold text-pastel-navy mb-2">{reviewCount}</div>
        <div className="text-sm text-gray-500">Từ đến hạn ôn tập</div>
      </div>
      <div className="bg-gradient-to-br from-pastel-green to-pastel-pink rounded-2xl p-6 shadow-lg flex flex-col items-center">
        <div className="text-4xl mb-2">📈</div>
        <h2 className="font-bold text-lg mb-1">Tổng số từ đã học</h2>
        <div className="text-2xl font-extrabold text-pastel-navy mb-2">{totalWords}</div>
        <div className="text-sm text-gray-500">Tổng số từ đã nhập</div>
      </div>
      <div className="bg-white rounded-2xl p-6 shadow-lg col-span-1 flex flex-col items-center">
        <div className="text-2xl mb-2">📊</div>
        <h2 className="font-bold text-lg mb-1">Phân bố mức độ ghi nhớ</h2>
        <div className="w-full h-40">
          <ResponsiveContainer>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
                label
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-white rounded-2xl p-6 shadow-lg col-span-2">
        <div className="text-2xl mb-2">📅</div>
        <h2 className="font-bold text-lg mb-1">Biểu đồ tiến độ 7 ngày</h2>
        <div className="h-48">
          <ResponsiveContainer>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="Từ mới" fill="#60a5fa" />
              <Bar dataKey="Ôn tập" fill="#fbbf24" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
